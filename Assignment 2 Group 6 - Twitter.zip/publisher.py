import tkinter as tk
from tkinter import messagebox
from paho.mqtt import client as mqtt

BROKER = "test.mosquitto.org"
PORT = 1883

def publish_tweet():
    username = entry_user.get().strip()
    topic = entry_topic.get().strip().lstrip("#").replace(" ", "_")
    tweet = text_msg.get("1.0", tk.END).strip()

    if not username or not topic or not tweet:
        messagebox.showwarning("Input Error", "Please fill all fields.")
        return

    msg = f"{username}: {tweet}"
    try:
        client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
        client.connect(BROKER, PORT, 60)
        result = client.publish(topic, msg)
        client.disconnect()

        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            messagebox.showinfo("Success", f"Tweet published to #{topic}")
            print(f"Published to #{topic}: {msg}")
            text_msg.delete("1.0", tk.END)
        else:
            messagebox.showerror("Error", f"Publish failed (code {result.rc})")
    except Exception as e:
        messagebox.showerror("Error", f"Publish failed:\n{e}")

# --- GUI -------------------------------------------------------
root = tk.Tk()
root.title("MQTT Twitter Publisher")
root.geometry("420x330")
root.resizable(False, False)

tk.Label(root, text="Username:", font=("Segoe UI", 11)).pack(pady=5)
entry_user = tk.Entry(root, width=30)
entry_user.pack()

tk.Label(root, text="Hashtag (topic):", font=("Segoe UI", 11)).pack(pady=5)
entry_topic = tk.Entry(root, width=30)
entry_topic.pack()

tk.Label(root, text="Tweet Message:", font=("Segoe UI", 11)).pack(pady=5)
text_msg = tk.Text(root, height=5, width=40)
text_msg.pack()

tk.Button(root, text="Publish Tweet", bg="#1DA1F2", fg="white",
          font=("Segoe UI", 11, "bold"), command=publish_tweet).pack(pady=10)

tk.Label(root, text=f"Broker: {BROKER}", fg="gray").pack(pady=5)

root.mainloop()
