# ===============================================
# subscriber.py - MQTT Twitter Subscriber (Hashtag Follower)
# Author: Achalise (Student ID)
# ===============================================

import tkinter as tk
from tkinter import messagebox
import paho.mqtt.client as mqtt
import threading

# --- MQTT Broker Setup ---
BROKER = "test.mosquitto.org"
PORT = 1883

class SubscriberApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Twitter Subscriber - Achalise")
        self.root.geometry("450x400")
        self.root.config(bg="#f4f4f4")

        # --- MQTT Client ---
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message

        try:
            self.client.connect(BROKER, PORT, 60)
            threading.Thread(target=self.client.loop_forever, daemon=True).start()
        except:
            messagebox.showerror("Connection Error", "Failed to connect to MQTT Broker")

        # --- GUI Components ---
        tk.Label(root, text="Hashtag (Topic):", bg="#f4f4f4").pack(pady=5)
        self.topic_entry = tk.Entry(root, width=40)
        self.topic_entry.pack(pady=5)

        button_frame = tk.Frame(root, bg="#f4f4f4")
        button_frame.pack(pady=10)
        tk.Button(button_frame, text="Subscribe", bg="#4CAF50", fg="white", command=self.subscribe_topic).grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Unsubscribe", bg="#f44336", fg="white", command=self.unsubscribe_topic).grid(row=0, column=1, padx=5)

        self.tweet_display = tk.Text(root, height=15, width=50, state='disabled')
        self.tweet_display.pack(pady=10)

        self.status_label = tk.Label(root, text="", fg="green", bg="#f4f4f4")
        self.status_label.pack(pady=5)

        self.subscribed_topic = None

    def on_connect(self, client, userdata, flags, rc):
        print("Connected with result code " + str(rc))

    def on_message(self, client, userdata, msg):
        tweet = msg.payload.decode()
        topic = msg.topic
        self.display_tweet(f"[{topic}] {tweet}")

    def subscribe_topic(self):
        topic = self.topic_entry.get().strip()
        if not topic:
            messagebox.showwarning("Input Error", "Please enter a hashtag to subscribe.")
            return
        topic = topic if topic.startswith("#") else "#" + topic

        self.client.subscribe(topic)
        self.subscribed_topic = topic
        self.status_label.config(text=f"Subscribed to {topic}")
        self.display_tweet(f"\n--- Now following {topic} ---\n")

    def unsubscribe_topic(self):
        if self.subscribed_topic:
            self.client.unsubscribe(self.subscribed_topic)
            self.display_tweet(f"\n--- Unsubscribed from {self.subscribed_topic} ---\n")
            self.status_label.config(text=f"Unsubscribed from {self.subscribed_topic}")
            self.subscribed_topic = None
        else:
            messagebox.showinfo("Info", "No active subscriptions.")

    def display_tweet(self, message):
        self.tweet_display.config(state='normal')
        self.tweet_display.insert(tk.END, message + "\n")
        self.tweet_display.config(state='disabled')
        self.tweet_display.see(tk.END)


if __name__ == "__main__":
    root = tk.Tk()
    app = SubscriberApp(root)
    root.mainloop()
